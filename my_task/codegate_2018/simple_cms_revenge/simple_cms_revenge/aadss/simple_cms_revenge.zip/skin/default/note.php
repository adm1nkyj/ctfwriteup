<?php if(!defined('simple_cms')) exit(); ?>
				<a href='?act=note&mid=recv'>recv</a> | <a href='?act=note&mid=sent'>sent</a> | <a href='?act=note&mid=write'>send note</a>